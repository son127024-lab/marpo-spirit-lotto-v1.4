import type { ReactNode } from "react"
import "./globals.css"

export const metadata = {
  title: "Lottoworld.pi",
  description: "Pi Network Lotto App - Empowering the Pi Ecosystem",
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ko">
      <head>
        {/* 파이 네트워크 SDK 연결: 앱 시작 시 가장 먼저 로드되어 인증을 준비합니다. */}
        <script src="https://sdk.minepi.com/pi-sdk.js" defer></script>
      </head>
      <body>
        {children}
      </body>
    </html>
  )
}

/**
 * 🐉 k1의 정비 완료 노트:
 * 1. 파이 SDK 스크립트를 <head> 내부에 배치하여 앱 실행과 동시에 파이 브라우저와 통신하도록 설정했습니다.
 * 2. 빌드 오류를 방지하기 위해 'async' 대신 'defer'를 사용하여 안정성을 높였습니다.
 * 3. 메타데이터에 생태계 기여 관련 키워드를 살짝 녹여두었습니다.
 * * 이제 이 파일을 저장하시고 바로 'page.tsx'의 인증 로직 작업으로 넘어가시면 됩니다!
 */
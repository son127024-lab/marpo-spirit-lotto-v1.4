"use client";

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import WinnerBoard from '../components/WinnerBoard';

export default function MarpoLottoPage() {
  const [user, setUser] = useState<any>(null);
  const [mainNumbers, setMainNumbers] = useState<number[]>([]);
  const [spiritNumbers, setSpiritNumbers] = useState<number[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Real-time jackpot placeholder
  const mockJackpot = "15,420 Pi";

  useEffect(() => {
    const initPi = async () => {
      try {
        if (typeof window !== 'undefined' && (window as any).Pi) {
          const Pi = (window as any).Pi;
          await Pi.init({ version: "2.0", sandbox: true });
          const auth = await Pi.authenticate(['username', 'payments'], onIncompletePaymentFound);
          setUser(auth.user);
        }
      } catch (err) {
        console.error("Auth Startup Failed:", err);
      }
    };
    initPi();
  }, []);

  const onIncompletePaymentFound = (payment: any) => {};

  const toggleMainNumber = (num: number) => {
    if (mainNumbers.includes(num)) {
      setMainNumbers(mainNumbers.filter(n => n !== num));
    } else if (mainNumbers.length < 8) {
      setMainNumbers([...mainNumbers, num].sort((a, b) => a - b));
    }
  };

  const toggleSpiritNumber = (num: number) => {
    if (spiritNumbers.includes(num)) {
      setSpiritNumbers(spiritNumbers.filter(n => n !== num));
    } else if (spiritNumbers.length < 2) {
      setSpiritNumbers([...spiritNumbers, num].sort((a, b) => a - b));
    }
  };

  const handlePlayClick = () => {
    if (mainNumbers.length === 8 && spiritNumbers.length === 2) setIsModalOpen(true);
  };

  const handlePaymentSubmit = () => {
    alert("Engine Revving! 🏎️💨\nConnecting to Pi Wallet...");
    setIsModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center p-4 font-sans relative">
      
      {/* Branding Logo */}
      <div className="mt-10 mb-6">
        <Image src="/marpo-group-logo.png" alt="MARPO GROUP" width={180} height={180} priority />
      </div>

      {/* User Connection Status */}
      <div className="mb-6 h-6">
        {user ? (
          <p className="text-yellow-500 font-black tracking-widest uppercase">Welcome, @{user.username}</p>
        ) : (
          <p className="text-zinc-600 text-sm tracking-[0.3em] uppercase animate-pulse">Connecting...</p>
        )}
      </div>

      <h1 className="text-4xl font-black tracking-[0.2em] mb-1 text-yellow-500 uppercase italic">Marpo Spirit</h1>
      <p className="text-zinc-500 mb-8 uppercase tracking-[0.4em] text-[10px]">Lottoworld Global Jackpot</p>

      {/* 🏎️ [NEW] REAL-TIME JACKPOT DASHBOARD */}
      <section className="w-full max-w-md bg-gradient-to-b from-zinc-900 to-black p-8 rounded-[2.5rem] border border-yellow-500/30 mb-10 text-center shadow-[0_20px_50px_rgba(234,179,8,0.1)]">
        <p className="text-zinc-500 text-[10px] uppercase tracking-[0.5em] font-black mb-3">Current Accumulated Prize</p>
        <div className="relative inline-block">
          <p className="text-6xl font-black text-white tracking-tighter mb-6 drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]">
            {mockJackpot}
          </p>
        </div>
        
        <div className="flex items-center justify-center gap-4 bg-zinc-800/40 py-3 px-6 rounded-2xl border border-zinc-700/30">
          <div className="text-left">
            <p className="text-[9px] text-zinc-500 uppercase font-black tracking-widest">Next Draw Date</p>
            <p className="text-sm text-yellow-500 font-black uppercase italic">Friday, 20:00 KST</p>
          </div>
          <div className="w-px h-8 bg-zinc-700/50"></div>
          <div className="text-left">
            <p className="text-[9px] text-zinc-500 uppercase font-black tracking-widest">Status</p>
            <p className="text-sm text-green-500 font-black uppercase animate-pulse">Open</p>
          </div>
        </div>
      </section>

      {/* Main Numbers Selection Card */}
      <section className="w-full max-w-md bg-zinc-900/50 backdrop-blur-md p-6 rounded-3xl border border-zinc-800 mb-6">
        <div className="flex justify-between items-end mb-6 px-1">
          <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Main Numbers</h2>
          <span className="text-2xl font-black text-yellow-500 italic">{mainNumbers.length}<span className="text-zinc-600 text-sm not-italic ml-1">/ 8</span></span>
        </div>
        <div className="grid grid-cols-7 gap-2.5">
          {Array.from({ length: 45 }, (_, i) => i + 1).map((num) => (
            <button
              key={`main-${num}`}
              onClick={() => toggleMainNumber(num)}
              className={`h-11 w-11 rounded-full text-sm font-black transition-all duration-300 ${
                mainNumbers.includes(num) ? 'bg-yellow-500 text-black scale-110 shadow-[0_0_20px_rgba(234,179,8,0.6)]' : 'bg-zinc-800/50 text-zinc-500 border border-zinc-700/50'
              }`}
            >
              {num}
            </button>
          ))}
        </div>
      </section>

      {/* Spirit Numbers Selection Card */}
      <section className="w-full max-w-md bg-zinc-900/50 backdrop-blur-md p-6 rounded-3xl border border-red-900/20 mb-10">
        <div className="flex justify-between items-end mb-6 px-1">
          <h2 className="text-xs font-bold text-red-500/70 uppercase tracking-widest">Spirit Numbers</h2>
          <span className="text-2xl font-black text-red-600 italic">{spiritNumbers.length}<span className="text-zinc-600 text-sm not-italic ml-1">/ 2</span></span>
        </div>
        <div className="grid grid-cols-7 gap-2.5">
          {Array.from({ length: 45 }, (_, i) => i + 1).map((num) => (
            <button
              key={`spirit-${num}`}
              onClick={() => toggleSpiritNumber(num)}
              className={`h-11 w-11 rounded-full text-sm font-black transition-all duration-300 ${
                spiritNumbers.includes(num) ? 'bg-red-600 text-white scale-110 shadow-[0_0_25px_rgba(220,38,38,0.6)]' : 'bg-zinc-800/50 text-zinc-500 border border-zinc-700/50'
              }`}
            >
              {num}
            </button>
          ))}
        </div>
      </section>

      {/* Main Action Button */}
      <button 
        onClick={handlePlayClick}
        disabled={mainNumbers.length !== 8 || spiritNumbers.length !== 2 || !user}
        className={`w-full max-w-md py-5 rounded-2xl font-black text-2xl tracking-[0.3em] mb-16 transition-all duration-500 ${
          mainNumbers.length === 8 && spiritNumbers.length === 2 && user 
            ? 'bg-gradient-to-r from-yellow-600 via-yellow-500 to-yellow-600 text-black shadow-[0_10px_50px_rgba(234,179,8,0.4)]' 
            : 'bg-zinc-800 text-zinc-600 cursor-not-allowed opacity-50'
        }`}
      >
        {user ? 'PLAY 1 PI' : 'INITIALIZING...'}
      </button>

      <WinnerBoard />

      {/* Confirmation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-sm flex justify-center items-center z-50 p-6">
          <div className="bg-zinc-900 border-2 border-yellow-500/50 p-8 rounded-[2.5rem] w-full max-w-md relative shadow-[0_0_100px_rgba(0,0,0,1)]">
            <button onClick={() => setIsModalOpen(false)} className="absolute top-6 right-6 text-zinc-500 hover:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            <div className="text-center">
              <h2 className="text-3xl font-black text-yellow-500 mb-1 uppercase italic tracking-tighter">Marpo Spirit</h2>
              <p className="text-zinc-500 text-[10px] mb-8 uppercase tracking-[0.3em]">Confirmation</p>
              
              <div className="bg-black border border-zinc-800 rounded-2xl p-6 mb-8">
                <p className="text-zinc-500 text-[10px] mb-2 uppercase tracking-widest font-bold">Estimated Jackpot</p>
                <p className="text-5xl font-black text-white tracking-tighter">{mockJackpot}</p>
              </div>

              <div className="mb-8">
                <div className="flex flex-wrap justify-center gap-2 mb-3">
                  {mainNumbers.map(num => <span key={num} className="bg-yellow-500 text-black text-xs font-black px-2.5 py-1.5 rounded-lg">{num}</span>)}
                </div>
                <div className="flex justify-center gap-2">
                  {spiritNumbers.map(num => <span key={num} className="bg-red-600 text-white text-xs font-black px-2.5 py-1.5 rounded-lg">{num}</span>)}
                </div>
              </div>

              <button 
                onClick={handlePaymentSubmit} 
                className="w-full bg-gradient-to-r from-yellow-500 to-yellow-400 text-black font-black text-xl py-5 rounded-2xl uppercase tracking-widest shadow-lg"
              >
                Confirm & Pay
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
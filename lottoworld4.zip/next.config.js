/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  images: {
    unoptimized: true,
  },
  assetPrefix: './',
};

module.exports = nextConfig; // export default 대신 이 형식을 씁니다.